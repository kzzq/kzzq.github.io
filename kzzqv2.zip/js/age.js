function ageSystem() {
    var ctrldob = new Date(2009, 5, 11);
    var ctrldoa = new Date();
    const msPerYear = 1000 * 60 * 60 * 24 * 365.2425;

    const diffMs = ctrldoa - ctrldob;
    const age = diffMs / msPerYear;

    const age_header = document.getElementById("age_header");
    if (age_header != null) {
        age_header.innerHTML = age.toFixed(3);
    }
}